import sys
import os
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense, Dropout, Input
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QPushButton, QMessageBox

class TrainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Train Model")
        self.setGeometry(300, 150, 400, 300)
        self.setStyleSheet("background-color: #34495E;")
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()

        title_label = QLabel("Train the Gesture Recognition Model")
        title_label.setStyleSheet("color: white; font-size: 18px; font-weight: bold;")
        layout.addWidget(title_label)

        train_button = QPushButton("Start Training")
        train_button.setStyleSheet("background-color: #2ECC71; color: white; font-size: 16px; padding: 10px;")
        train_button.clicked.connect(self.start_training)
        layout.addWidget(train_button)

        self.setLayout(layout)

    def start_training(self):
        csv_path = 'gesture_data/gesture_landmarks.csv'
        if not os.path.exists(csv_path):
            QMessageBox.warning(self, 'Error', 'No gesture data found. Please collect data first.')
            return

        data = pd.read_csv(csv_path)
        X = data.iloc[:, 1:].values
        y = data.iloc[:, 0].values

        le = LabelEncoder()
        y_encoded = le.fit_transform(y)

        X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.2, random_state=42)

        model = Sequential([
            Input(shape=(X_train.shape[1],)),
            Dense(128, activation='relu'),
            Dropout(0.2),
            Dense(64, activation='relu'),
            Dense(len(set(y)), activation='softmax')
        ])

        model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
        model.fit(X_train, y_train, epochs=20, validation_data=(X_test, y_test))
        model.save('models/gesture_recognition_model.h5')

        QMessageBox.information(self, 'Training Complete', 'Model training is complete!')

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = TrainWindow()
    window.show()
    sys.exit(app.exec_())
