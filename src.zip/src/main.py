import sys
import subprocess
import os
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout, QMessageBox, QLabel, QHBoxLayout
from PyQt5.QtGui import QIcon, QFont, QPixmap
from PyQt5.QtCore import Qt

class MainMenu(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Gesture Recognition System")
        self.setGeometry(200, 100, 500, 750)  # Increased window height to fit logo
        self.setStyleSheet("background-color: #CDCDCD;")
        self.init_ui()

    def init_ui(self):
        """Initializes the UI with buttons, labels, and layout."""
        
        # ** Logo Section **
        self.logo_label = QLabel(self)
        logo_path = os.path.join(os.path.dirname(__file__), 'qstss.png')  # Change the path if needed
        if os.path.exists(logo_path):
            pixmap = QPixmap(logo_path)
            self.logo_label.setPixmap(pixmap.scaled(150, 150, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        else:
            self.logo_label.setText("🤖 Gesture Recognition System 🤖")
            self.logo_label.setStyleSheet("""
                color: #ECF0F1; 
                font-size: 24px; 
                font-weight: bold; 
            """)
            self.logo_label.setAlignment(Qt.AlignCenter)

        # ** Main Title **
        self.title_label = QLabel("Gesture Recognition System")
        self.title_label.setStyleSheet("""
            color: #ECF0F1; 
            font-size: 28px; 
            font-weight: bold; 
            padding: 10px;
        """)
        self.title_label.setAlignment(Qt.AlignCenter)
        
        # ** Buttons **
        self.add_gesture_button = self.create_button(
            text="➕ Add / Manage Gestures", 
            color="#9B59B6", 
            hover_color="#8E44AD", 
            action=self.start_add_gesture
        )

        self.collect_data_button = self.create_button(
            text="📷 Collect Data", 
            color="#3498DB", 
            hover_color="#2980B9", 
            action=self.start_collect_data
        )
        
        self.train_model_button = self.create_button(
            text="📚 Train Model", 
            color="#2ECC71", 
            hover_color="#27AE60", 
            action=self.start_train_model
        )
        
        self.translate_button = self.create_button(
            text="🖐️ Translate Gestures", 
            color="#F39C12", 
            hover_color="#E67E22", 
            action=self.start_translation
        )
        

        self.exit_button = self.create_button(
            text="❌ Exit", 
            color="#E74C3C", 
            hover_color="#C0392B", 
            action=self.confirm_exit
        )

        # ** Layout Setup **
        layout = QVBoxLayout()
        layout.addWidget(self.logo_label, alignment=Qt.AlignCenter)  # ** Logo at the top **
        layout.addWidget(self.title_label)
        layout.addWidget(self.add_gesture_button)
        layout.addWidget(self.collect_data_button)
        layout.addWidget(self.train_model_button)
        layout.addWidget(self.translate_button)
        layout.addWidget(self.exit_button)

        # Centering and spacing
        layout.setSpacing(20)
        layout.setAlignment(Qt.AlignCenter)
        self.setLayout(layout)

    def create_button(self, text, color, hover_color, action):
        """Creates a styled button with hover effects."""
        button = QPushButton(text)
        button.setFont(QFont("Arial", 16, QFont.Bold))  # Bold font for the button
        button.setStyleSheet(f"""
            QPushButton {{
                background-color: {color};
                color: white;
                border-radius: 15px;
                padding: 15px;
                font-weight: bold;
            }}
            QPushButton:hover {{
                background-color: {hover_color};
            }}
        """)
        button.setCursor(Qt.PointingHandCursor)
        button.clicked.connect(action)
        return button

    def start_collect_data(self):
        """Starts the data collection process."""
        reply = self.custom_message_box('Start Collect Data', 
                                        'Do you want to start collecting gesture data?')
        if reply == QMessageBox.Yes:
            self.display_message('📷 Collecting data...')
            subprocess.Popen(['python', 'collect.py'])

    def start_train_model(self):
        """Starts the model training process."""
        reply = self.custom_message_box('Train Model', 
                                        'Do you want to start training the model?')
        if reply == QMessageBox.Yes:
            self.display_message('📚 Training model...')
            subprocess.Popen(['python', 'train.py'])

    def start_translation(self):
        """Starts the gesture translation process."""
        reply = self.custom_message_box('Start Translation', 
                                        'Do you want to start real-time gesture translation?')
        if reply == QMessageBox.Yes:
            self.display_message('🖐️ Starting translation...')
            subprocess.Popen(['python', 'translate.py'])

    def start_add_gesture(self):
        """Starts the add gesture management process."""
        reply = self.custom_message_box('Manage Gestures', 
                                        'Do you want to add, delete, or modify gestures?')
        if reply == QMessageBox.Yes:
            self.display_message('➕ Opening gesture manager...')
            subprocess.Popen(['python', 'add_gesture.py'])

    def confirm_exit(self):
        """Exits the application after user confirmation."""
        reply = self.custom_message_box('Exit Application', 
                                        'Are you sure you want to exit?')
        if reply == QMessageBox.Yes:
            self.close()

    def display_message(self, message):
        """Displays a message in a custom pop-up window."""
        QMessageBox.information(self, 'Info', message, QMessageBox.Ok)

    def custom_message_box(self, title, message):
        """Creates a custom message box with bold white font and a dark background."""
        msg_box = QMessageBox(self)
        msg_box.setWindowTitle(title)
        msg_box.setText(message)
        msg_box.setStandardButtons(QMessageBox.Yes | QMessageBox.No)
        msg_box.setStyleSheet("""
            QMessageBox {{
                background-color: #2C3E50; 
                color: white; 
                font-weight: bold; 
                font-size: 16px;
            }}
            QPushButton {{
                background-color: #3498DB; 
                color: white; 
                font-weight: bold; 
                border-radius: 10px; 
                padding: 10px;
            }}
            QPushButton:hover {{
                background-color: #2980B9;
            }}
        """)
        reply = msg_box.exec()
        return reply


def main():
    app = QApplication(sys.argv)
    window = MainMenu()
    window.show()
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()
