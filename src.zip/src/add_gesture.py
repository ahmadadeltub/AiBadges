import sys
import os
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox, QListWidget
from PyQt5.QtCore import Qt  # This import is required for Qt.AlignCenter


class AddGestureWindow(QWidget):
    GESTURES_FILE = 'gestures.txt'

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Add / Manage Gestures")
        self.setGeometry(300, 150, 500, 600)
        self.setStyleSheet("background-color: #808080;")
        self.init_ui()

    def init_ui(self):
        """Initializes the user interface."""
        layout = QVBoxLayout()

        # ** Title **
        self.title_label = QLabel("Manage Gestures")
        self.title_label.setStyleSheet("""
            color: #ECF0F1; 
            font-size: 24px; 
            font-weight: bold; 
            padding: 10px;
        """)
        self.title_label.setAlignment(Qt.AlignCenter)
        
        # ** Gesture List (To show existing gestures) **
        self.gesture_list = QListWidget()
        self.load_gestures()
        
        # ** Input Field (For adding and modifying gestures) **
        self.gesture_input = QLineEdit()
        self.gesture_input.setPlaceholderText("Enter gesture name")
        self.gesture_input.setStyleSheet("padding: 10px; border-radius: 10px; font-size: 16px;")
        
        # ** Buttons for Add, Modify, and Delete **
        self.add_button = QPushButton("➕ Add Gesture")
        self.modify_button = QPushButton("✏️ Modify Gesture")
        self.delete_button = QPushButton("🗑️ Delete Gesture")

        self.add_button.setStyleSheet("""
            background-color: #3498DB; 
            color: white; 
            font-size: 16px; 
            border-radius: 10px; 
            padding: 10px;
        """)
        self.modify_button.setStyleSheet("""
            background-color: #F1C40F; 
            color: white; 
            font-size: 16px; 
            border-radius: 10px; 
            padding: 10px;
        """)
        self.delete_button.setStyleSheet("""
            background-color: #E74C3C; 
            color: white; 
            font-size: 16px; 
            border-radius: 10px; 
            padding: 10px;
        """)

        self.add_button.clicked.connect(self.add_gesture)
        self.modify_button.clicked.connect(self.modify_gesture)
        self.delete_button.clicked.connect(self.delete_gesture)

        # ** Layout Setup **
        layout.addWidget(self.title_label)
        layout.addWidget(QLabel("All Gestures (Click to Select)"))
        layout.addWidget(self.gesture_list)
        layout.addWidget(self.gesture_input)
        layout.addWidget(self.add_button)
        layout.addWidget(self.modify_button)
        layout.addWidget(self.delete_button)

        self.setLayout(layout)

    def load_gestures(self):
        """Loads gestures from the gestures.txt file and displays them in the list."""
        self.gesture_list.clear()
        if os.path.exists(self.GESTURES_FILE):
            with open(self.GESTURES_FILE, 'r') as file:
                gestures = file.read().splitlines()
                self.gesture_list.addItems(gestures)

    def add_gesture(self):
        """Adds a new gesture to the system."""
        gesture = self.gesture_input.text().strip()
        if not gesture:
            QMessageBox.warning(self, 'Invalid Input', 'Please enter a gesture name.')
            return

        if gesture in self.get_gesture_list():
            QMessageBox.warning(self, 'Duplicate Gesture', f"The gesture '{gesture}' already exists.")
            return

        with open(self.GESTURES_FILE, 'a') as file:
            file.write(gesture + '\n')
        
        self.gesture_list.addItem(gesture)
        self.gesture_input.clear()
        QMessageBox.information(self, 'Success', f"Gesture '{gesture}' added successfully.")

    def modify_gesture(self):
        """Modifies the selected gesture's name."""
        selected_item = self.gesture_list.currentItem()
        if selected_item:
            old_name = selected_item.text()
            new_name = self.gesture_input.text().strip()
            if not new_name:
                QMessageBox.warning(self, 'Invalid Input', 'Please enter a gesture name.')
                return

            if new_name in self.get_gesture_list():
                QMessageBox.warning(self, 'Duplicate Gesture', f"The gesture '{new_name}' already exists.")
                return

            selected_item.setText(new_name)
            self.save_gestures()
            QMessageBox.information(self, 'Success', f"Gesture '{old_name}' updated to '{new_name}'.")

    def delete_gesture(self):
        """Deletes the selected gesture from the system."""
        selected_item = self.gesture_list.currentItem()
        if selected_item:
            gesture = selected_item.text()
            reply = QMessageBox.question(self, 'Delete Gesture', 
                                         f"Are you sure you want to delete '{gesture}'?", 
                                         QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.Yes:
                self.gesture_list.takeItem(self.gesture_list.row(selected_item))
                self.save_gestures()
                QMessageBox.information(self, 'Success', f"Gesture '{gesture}' has been deleted.")

    def save_gestures(self):
        """Saves all gestures from the list back to the gestures.txt file."""
        with open(self.GESTURES_FILE, 'w') as file:
            for i in range(self.gesture_list.count()):
                file.write(self.gesture_list.item(i).text() + '\n')

    def get_gesture_list(self):
        """Returns the list of gestures currently in the QListWidget."""
        return [self.gesture_list.item(i).text() for i in range(self.gesture_list.count())]


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = AddGestureWindow()
    window.show()
    sys.exit(app.exec_())
