import sys
import os
import cv2
import csv
import mediapipe as mp
import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder, StandardScaler
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense, Dropout, Input
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.optimizers import Adam
import pyttsx3
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QLineEdit, QPushButton, QMessageBox, QListWidget, QComboBox, QHBoxLayout
from PyQt5.QtGui import QPixmap, QImage, QFont
from PyQt5.QtCore import Qt, QTimer, QThread, pyqtSignal

# Add Gesture Window
class AddGestureWindow(QWidget):
    GESTURES_FILE = 'gesture_data/gestures.txt'

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Add / Manage Gestures")
        self.setGeometry(300, 150, 500, 600)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()
        self.title_label = QLabel("Manage Gestures")
        self.gesture_list = QListWidget()
        self.load_gestures()
        self.gesture_input = QLineEdit()
        self.gesture_input.setPlaceholderText("Enter gesture name")

        # Buttons
        button_layout = QHBoxLayout()
        self.add_button = QPushButton("Add Gesture")
        self.modify_button = QPushButton("Modify Gesture")
        self.delete_button = QPushButton("Delete Gesture")
        button_layout.addWidget(self.add_button)
        button_layout.addWidget(self.modify_button)
        button_layout.addWidget(self.delete_button)

        # Connect buttons
        self.add_button.clicked.connect(self.add_gesture)
        self.modify_button.clicked.connect(self.modify_gesture)
        self.delete_button.clicked.connect(self.delete_gesture)

        # Layout setup
        layout.addWidget(self.title_label)
        layout.addWidget(self.gesture_list)
        layout.addWidget(self.gesture_input)
        layout.addLayout(button_layout)
        self.setLayout(layout)

    def load_gestures(self):
        self.gesture_list.clear()
        if os.path.exists(self.GESTURES_FILE):
            with open(self.GESTURES_FILE, 'r') as file:
                gestures = file.read().splitlines()
                self.gesture_list.addItems(gestures)

    def add_gesture(self):
        gesture = self.gesture_input.text().strip()
        if not gesture:
            QMessageBox.warning(self, "Error", "Please enter a gesture name.")
            return
        if gesture in self.get_gesture_list():
            QMessageBox.warning(self, "Error", "Gesture already exists.")
            return

        with open(self.GESTURES_FILE, 'a') as file:
            file.write(gesture + '\n')
        self.gesture_list.addItem(gesture)
        self.gesture_input.clear()
        QMessageBox.information(self, "Success", f"Gesture '{gesture}' added successfully.")

    def modify_gesture(self):
        selected_item = self.gesture_list.currentItem()
        if not selected_item:
            QMessageBox.warning(self, "Error", "Please select a gesture to modify.")
            return

        new_gesture = self.gesture_input.text().strip()
        if not new_gesture:
            QMessageBox.warning(self, "Error", "Please enter the new gesture name.")
            return
        if new_gesture in self.get_gesture_list():
            QMessageBox.warning(self, "Error", "Gesture already exists.")
            return

        # Modify the selected gesture
        old_gesture = selected_item.text()
        selected_item.setText(new_gesture)
        self.save_gestures()
        QMessageBox.information(self, "Success", f"Gesture '{old_gesture}' modified to '{new_gesture}'.")

    def delete_gesture(self):
        selected_item = self.gesture_list.currentItem()
        if not selected_item:
            QMessageBox.warning(self, "Error", "Please select a gesture to delete.")
            return

        reply = QMessageBox.question(self, "Delete Gesture", f"Are you sure you want to delete '{selected_item.text()}'?",
                                     QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if reply == QMessageBox.Yes:
            self.gesture_list.takeItem(self.gesture_list.row(selected_item))
            self.save_gestures()
            QMessageBox.information(self, "Success", f"Gesture '{selected_item.text()}' deleted successfully.")

    def save_gestures(self):
        with open(self.GESTURES_FILE, 'w') as file:
            for i in range(self.gesture_list.count()):
                file.write(self.gesture_list.item(i).text() + '\n')

    def get_gesture_list(self):
        return [self.gesture_list.item(i).text() for i in range(self.gesture_list.count())]

# Collect Data Window
class DataCollectionThread(QThread):
    collection_complete = pyqtSignal(str)

    def __init__(self, gesture_name):
        super().__init__()
        self.gesture_name = gesture_name
        self.running = True

    def run(self):
        DATA_DIR = 'gesture_data'
        CSV_FILE = os.path.join(DATA_DIR, 'gesture_landmarks.csv')
        os.makedirs(DATA_DIR, exist_ok=True)
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            self.collection_complete.emit("Error: Could not open the camera.")
            return

        mp_hands = mp.solutions.hands
        hands = mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7)
        collected_samples = 0
        required_samples = 200

        while collected_samples < required_samples and self.running:
            ret, frame = cap.read()
            if not ret:
                continue

            frame = cv2.flip(frame, 1)
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(rgb_frame)

            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    try:
                        landmarks = [lm for point in hand_landmarks.landmark for lm in (point.x, point.y, point.z)]
                        data_row = [self.gesture_name] + landmarks
                        with open(CSV_FILE, 'a', newline='') as file:
                            writer = csv.writer(file)
                            writer.writerow(data_row)
                        collected_samples += 1
                        mp.solutions.drawing_utils.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)
                    except Exception as e:
                        print(f"Error processing landmarks: {e}")

            cv2.putText(frame, f"Gesture: {self.gesture_name}", (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            cv2.putText(frame, f"Samples: {collected_samples}/{required_samples}", (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

            cv2.imshow("Collect Hand Gestures", frame)

            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break

        cap.release()
        hands.close()
        cv2.destroyAllWindows()

        if collected_samples >= required_samples:
            self.collection_complete.emit(f"Collected {collected_samples} samples for gesture '{self.gesture_name}'.")
        else:
            self.collection_complete.emit("Data collection incomplete.")

    def stop(self):
        self.running = False

# Collect Data Window
class CollectDataWindow(QWidget):
    GESTURES_FILE = 'gesture_data/gestures.txt'

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Collect Data")
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()
        self.gesture_dropdown = QComboBox()
        self.load_gestures()
        self.start_button = QPushButton("Start Collecting Data")
        self.start_button.clicked.connect(self.start_collection)
        layout.addWidget(self.gesture_dropdown)
        layout.addWidget(self.start_button)
        self.setLayout(layout)

    def load_gestures(self):
        if os.path.exists(self.GESTURES_FILE):
            with open(self.GESTURES_FILE, 'r') as file:
                gestures = file.read().splitlines()
                self.gesture_dropdown.addItems(gestures)

    def start_collection(self):
        gesture = self.gesture_dropdown.currentText()
        if not gesture:
            QMessageBox.warning(self, "Error", "Select a gesture first.")
            return

        self.collection_thread = DataCollectionThread(gesture)
        self.collection_thread.collection_complete.connect(self.on_collection_complete)
        self.collection_thread.start()

    def on_collection_complete(self, message):
        QMessageBox.information(self, "Info", message)

    def closeEvent(self, event):
        if hasattr(self, 'collection_thread') and self.collection_thread.isRunning():
            self.collection_thread.stop()
            self.collection_thread.wait()
        event.accept()

# Remaining classes (TrainWindow, TranslateWindow, MainMenu) remain unchanged.


# Train Model Window
class TrainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Train Model")
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()
        self.train_button = QPushButton("Start Training")
        self.train_button.clicked.connect(self.train_model)
        layout.addWidget(self.train_button)
        self.setLayout(layout)

    def train_model(self):
        try:
            csv_path = 'gesture_data/gesture_landmarks.csv'
            if not os.path.exists(csv_path):
                QMessageBox.warning(self, "Error", "No data found. Collect gesture data first.")
                return

            data = pd.read_csv(csv_path)
            X = data.iloc[:, 1:].values
            y = data.iloc[:, 0].values

            le = LabelEncoder()
            y_encoded = le.fit_transform(y)
            X_train, X_test, y_train, y_test = train_test_split(X, y_encoded, test_size=0.2, random_state=42)

            scaler = StandardScaler()
            X_train = scaler.fit_transform(X_train)
            X_test = scaler.transform(X_test)

            model = Sequential([
                Input(shape=(X_train.shape[1],)),
                Dense(128, activation='relu'),
                Dropout(0.2),
                Dense(64, activation='relu'),
                Dense(len(np.unique(y_encoded)), activation='softmax')
            ])

            model.compile(optimizer=Adam(), loss='sparse_categorical_crossentropy', metrics=['accuracy'])
            early_stopping = EarlyStopping(monitor='val_loss', patience=3)
            reduce_lr = ReduceLROnPlateau(monitor='val_loss', factor=0.5, patience=2)

            model.fit(X_train, y_train, validation_data=(X_test, y_test), epochs=20, callbacks=[early_stopping, reduce_lr])
            os.makedirs('models', exist_ok=True)
            model.save('models/gesture_recognition_model.keras')
            joblib.dump(scaler, 'models/scaler.save')
            joblib.dump(le, 'models/label_encoder.save')

            QMessageBox.information(self, "Success", "Model trained and saved successfully!")
        except Exception as e:
            QMessageBox.critical(self, "Error", f"Training failed: {str(e)}")

# Translate Gestures Window
class TranslateWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Translate Gestures")
        self.init_ui()
        self.hands = mp.solutions.hands.Hands(max_num_hands=1, min_detection_confidence=0.7)
        self.engine = pyttsx3.init()

        # Load model
        self.model = load_model('models/gesture_recognition_model.keras')
        self.scaler = joblib.load('models/scaler.save')
        self.label_encoder = joblib.load('models/label_encoder.save')

        self.cap = cv2.VideoCapture(0)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(30)

    def init_ui(self):
        layout = QVBoxLayout()
        self.video_label = QLabel()
        layout.addWidget(self.video_label)
        self.setLayout(layout)

    def update_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            return

        frame = cv2.flip(frame, 1)  # Flip horizontally for a normal camera view
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.hands.process(frame_rgb)

        gesture = "Not Detected"
        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                landmarks = [lm for point in hand_landmarks.landmark for lm in (point.x, point.y, point.z)]
                X = self.scaler.transform(np.array(landmarks).reshape(1, -1))
                prediction = self.model.predict(X)
                class_id = np.argmax(prediction)
                gesture = self.label_encoder.inverse_transform([class_id])[0]
                self.engine.say(gesture)
                self.engine.runAndWait()

        cv2.putText(frame, f"Gesture: {gesture}", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
        qt_image = QImage(frame.data, frame.shape[1], frame.shape[0], QImage.Format_RGB888)
        self.video_label.setPixmap(QPixmap.fromImage(qt_image))

    def closeEvent(self, event):
        self.cap.release()
        self.hands.close()
        event.accept()

# Main Menu
class MainMenu(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Gesture Recognition System")
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()
        self.add_button = QPushButton("Manage Gestures")
        self.collect_button = QPushButton("Collect Data")
        self.train_button = QPushButton("Train Model")
        self.translate_button = QPushButton("Translate Gestures")
        self.add_button.clicked.connect(self.open_add_gesture)
        self.collect_button.clicked.connect(self.open_collect_data)
        self.train_button.clicked.connect(self.open_train_model)
        self.translate_button.clicked.connect(self.open_translate_window)
        layout.addWidget(self.add_button)
        layout.addWidget(self.collect_button)
        layout.addWidget(self.train_button)
        layout.addWidget(self.translate_button)
        self.setLayout(layout)

    def open_add_gesture(self):
        self.add_window = AddGestureWindow()
        self.add_window.show()

    def open_collect_data(self):
        self.collect_window = CollectDataWindow()
        self.collect_window.show()

    def open_train_model(self):
        self.train_window = TrainWindow()
        self.train_window.show()

    def open_translate_window(self):
        self.translate_window = TranslateWindow()
        self.translate_window.show()

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainMenu()
    window.show()
    sys.exit(app.exec_())
