### translate.py
import sys
import os
import cv2
import mediapipe as mp
import numpy as np
import joblib
from tensorflow.keras.models import load_model
import pyttsx3
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QHBoxLayout
from PyQt5.QtGui import QPixmap, QImage, QFont
from PyQt5.QtCore import Qt, QTimer
class TranslateWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Real-Time Gesture Translation")
        self.setGeometry(100, 100, 800, 600)
        self.setStyleSheet("background-color: #2C3E50;")
        self.init_ui()

        # Load AI models
        self.model, self.scaler, self.label_encoder = self.load_models()
        self.mp_hands = mp.solutions.hands
        self.hands = self.mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7)
        self.mp_draw = mp.solutions.drawing_utils

        self.engine = pyttsx3.init()

        # Webcam setup
        self.cap = cv2.VideoCapture(0)
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_frame)
        self.timer.start(30)

    def init_ui(self):
        layout = QVBoxLayout()
        self.video_label = QLabel(self)
        self.video_label.setFixedSize(640, 480)
        self.video_label.setStyleSheet("background-color: black;")
        layout.addWidget(self.video_label, alignment=Qt.AlignCenter)

        button_layout = QHBoxLayout()
        self.back_button = self.create_button("🔙 Back", self.go_back)
        self.exit_button = self.create_button("❌ Exit", self.exit_application)

        button_layout.addWidget(self.back_button)
        button_layout.addWidget(self.exit_button)

        layout.addLayout(button_layout)
        self.setLayout(layout)

    def create_button(self, text, action):
        button = QPushButton(text)
        button.setFont(QFont("Arial", 14, QFont.Bold))
        button.setStyleSheet("padding: 10px;")
        button.setCursor(Qt.PointingHandCursor)
        button.clicked.connect(action)
        return button

    def go_back(self):
        self.stop_translation()
        self.close()

    def exit_application(self):
        self.stop_translation()
        sys.exit()

    def load_models(self):
        try:
            model_path = os.path.join(os.path.dirname(__file__), 'models', 'gesture_recognition_model.h5')
            scaler_path = os.path.join(os.path.dirname(__file__), 'models', 'scaler.save')
            label_encoder_path = os.path.join(os.path.dirname(__file__), 'models', 'label_encoder.save')

            model = load_model(model_path)
            scaler = joblib.load(scaler_path)
            label_encoder = joblib.load(label_encoder_path)

            print("[INFO] Models loaded successfully.")
            return model, scaler, label_encoder
        except Exception as e:
            print(f"[ERROR] Failed to load models: {e}")
            sys.exit(1)

    def extract_landmarks(self, hand_landmarks):
        return [lm for point in hand_landmarks.landmark for lm in (point.x, point.y, point.z)]

    def update_frame(self):
        ret, frame = self.cap.read()
        if not ret:
            return

        frame = cv2.flip(frame, 1)
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.hands.process(rgb_frame)

        gesture = ''

        if results.multi_hand_landmarks:
            for hand_landmarks in results.multi_hand_landmarks:
                self.mp_draw.draw_landmarks(frame, hand_landmarks, self.mp_hands.HAND_CONNECTIONS)
                landmarks = self.extract_landmarks(hand_landmarks)
                X = np.array(landmarks).reshape(1, -1)
                X_scaled = self.scaler.transform(X)
                prediction = self.model.predict(X_scaled)
                class_id = np.argmax(prediction)
                confidence = prediction[0][class_id]

                if confidence > 0.75:
                    gesture = self.label_encoder.inverse_transform([class_id])[0]

        if gesture:
            cv2.putText(frame, f"Gesture: {gesture}", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            self.speak(gesture)
        else:
            cv2.putText(frame, "Gesture: Not Detected", (10, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 255), 2)

        h, w, ch = frame.shape
        qt_image = QImage(frame.data, w, h, 3 * w, QImage.Format_BGR888)
        self.video_label.setPixmap(QPixmap.fromImage(qt_image))

    def speak(self, text):
        self.engine.say(text)
        self.engine.runAndWait()

    def stop_translation(self):
        if hasattr(self, 'cap') and self.cap.isOpened():
            self.cap.release()
        if hasattr(self, 'timer'):
            self.timer.stop()
        self.hands.close()
        print("[INFO] Translation stopped.")

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = TranslateWindow()
    window.show()
    sys.exit(app.exec_())
