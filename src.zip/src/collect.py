

### collect.py
import sys
import os
import cv2
import csv
import mediapipe as mp
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QLabel, QComboBox, QPushButton, QMessageBox
from PyQt5.QtCore import Qt, QThread, pyqtSignal

class DataCollectionThread(QThread):
    update_image = pyqtSignal()
    collection_complete = pyqtSignal(str)

    def __init__(self, gesture_name):
        super().__init__()
        self.gesture_name = gesture_name
        self.running = True

    def run(self):
        DATA_DIR = 'gesture_data'
        CSV_FILE = os.path.join(DATA_DIR, 'gesture_landmarks.csv')

        if not os.path.exists(DATA_DIR):
            os.makedirs(DATA_DIR)

        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            self.collection_complete.emit(f"Error: Could not open the camera.")
            return

        mp_hands = mp.solutions.hands
        hands = mp_hands.Hands(max_num_hands=1, min_detection_confidence=0.7)
        mp_draw = mp.solutions.drawing_utils

        collected_samples = 0
        required_samples = 200  # Number of samples per gesture

        while collected_samples < required_samples and self.running:
            ret, frame = cap.read()
            if not ret:
                continue

            frame = cv2.flip(frame, 1)  # Flip the image horizontally
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            results = hands.process(rgb_frame)

            if results.multi_hand_landmarks:
                for hand_landmarks in results.multi_hand_landmarks:
                    # Draw landmarks (dots) and connections (lines) on the frame
                    mp_draw.draw_landmarks(frame, hand_landmarks, mp_hands.HAND_CONNECTIONS)

                    # Extract landmarks (x, y, z) for each of the 21 points
                    try:
                        landmarks = [lm for point in hand_landmarks.landmark for lm in (point.x, point.y, point.z)]
                        data_row = [self.gesture_name] + landmarks

                        with open(CSV_FILE, mode='a', newline='') as file:
                            writer = csv.writer(file)
                            writer.writerow(data_row)

                        collected_samples += 1
                    except Exception as e:
                        print(f"Error processing landmarks: {e}")

            # **Visual Feedback on the Frame**
            cv2.putText(frame, f'Gesture: {self.gesture_name}', (10, 30), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            cv2.putText(frame, f'Samples: {collected_samples}/{required_samples}', (10, 60), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)

            # Display the frame
            cv2.imshow("Collect Hand Gestures", frame)

            key = cv2.waitKey(1) & 0xFF
            if key == ord('q'):
                break

        cap.release()
        cv2.destroyAllWindows()
        hands.close()

        if collected_samples >= required_samples:
            self.collection_complete.emit(f"Successfully collected {collected_samples} samples for gesture '{self.gesture_name}'.")
        else:
            self.collection_complete.emit("Data collection was stopped before completion.")

    def stop(self):
        """Stops the data collection thread."""
        self.running = False


class CollectDataWindow(QWidget):
    GESTURES_FILE = 'gestures.txt'

    def __init__(self):
        super().__init__()
        self.setWindowTitle("Collect Data")
        self.setGeometry(300, 150, 400, 350)
        self.setStyleSheet("background-color: #2C3E50;")
        self.init_ui()

        self.collection_thread = None  # To store the QThread for data collection

    def init_ui(self):
        """Initializes the user interface for the Collect Data window."""
        layout = QVBoxLayout()

        # Title
        self.title_label = QLabel("Select Gesture to Collect Data")
        self.title_label.setStyleSheet("""
            color: white; 
            font-size: 18px; 
            font-weight: bold; 
            padding: 10px;
        """)

        # Gesture Dropdown (To select the gesture)
        self.gesture_dropdown = QComboBox()
        self.load_gestures()

        # Start Button
        self.start_button = QPushButton("Start Collecting Data")
        self.start_button.setStyleSheet("""
            background-color: #2ECC71; 
            color: white; 
            font-size: 16px; 
            border-radius: 10px; 
            padding: 10px;
        """)
        self.start_button.clicked.connect(self.start_collection)

        layout.addWidget(self.title_label)
        layout.addWidget(self.gesture_dropdown)
        layout.addWidget(self.start_button)

        self.setLayout(layout)

    def load_gestures(self):
        """Loads the gestures from gestures.txt into the dropdown menu."""
        if os.path.exists(self.GESTURES_FILE):
            with open(self.GESTURES_FILE, 'r') as file:
                gestures = file.read().splitlines()
                self.gesture_dropdown.addItems(gestures)

    def start_collection(self):
        """Starts the data collection process for the selected gesture."""
        gesture = self.gesture_dropdown.currentText()
        if not gesture:
            QMessageBox.warning(self, 'Error', 'Please select a gesture from the list.')
            return

        QMessageBox.information(self, 'Start Collection', f'Starting collection for "{gesture}".')

        # ** Start the Data Collection Thread **
        self.collection_thread = DataCollectionThread(gesture_name=gesture)
        self.collection_thread.collection_complete.connect(self.on_collection_complete)
        self.collection_thread.start()

    def on_collection_complete(self, message):
        """Handles the event when data collection is complete."""
        QMessageBox.information(self, 'Data Collection Complete', message)

    def closeEvent(self, event):
        """Ensures the data collection thread is properly stopped when the window is closed."""
        if self.collection_thread is not None and self.collection_thread.isRunning():
            self.collection_thread.stop()
            self.collection_thread.wait()
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = CollectDataWindow()
    window.show()
    sys.exit(app.exec_())

